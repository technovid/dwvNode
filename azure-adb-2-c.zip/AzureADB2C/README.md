# Cancellation Token on Console Application

## Content

-   YouTube: <https://youtu.be/_96i16aAnSQ?si=01nxaegggym7zfMW>
